import React, { useState } from "react";
import { Users, X, TrendingUp } from "lucide-react";
import axios from "axios";

const CrowdPredictionWidget = () => {

  const [isOpen, setIsOpen] = useState(false);

  const [formData, setFormData] = useState({
    temperature: "",
    humidity: "",
    rainfall: "",
    holiday: "0",
    weekend: "0",
    hour: "",
  });

  const [prediction, setPrediction] = useState(null);

  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const predictCrowd = async (e) => {
    e.preventDefault();

    setLoading(true);

    try {

      const response = await axios.post(
        "http://127.0.0.1:8000/api/crowd/predict/",
        formData
      );

      setPrediction(response.data);

    } catch (error) {

      console.error(error);

      alert("Prediction failed");

    } finally {

      setLoading(false);

    }
  };

  return (
    <>

      {/* FLOATING BUTTON */}

      <button
        onClick={() => setIsOpen(true)}
        className="
          fixed
          bottom-24
          right-6
          z-[999]
          bg-orange-500
          hover:bg-orange-600
          text-white
          p-4
          rounded-full
          shadow-2xl
          transition-all
          duration-300
          hover:scale-110
        "
      >
        <Users className="w-6 h-6" />
      </button>

      {/* POPUP */}

      {isOpen && (

        <div
          className="
            fixed
            bottom-40
            right-6
            w-[360px]
            bg-white
            rounded-3xl
            shadow-2xl
            border
            border-gray-200
            z-[999]
            overflow-hidden
          "
        >

          {/* HEADER */}

          <div
            className="
              bg-orange-500
              text-white
              px-5
              py-4
              flex
              items-center
              justify-between
            "
          >

            <div className="flex items-center gap-3">

              <TrendingUp className="w-6 h-6" />

              <div>

                <h2 className="font-bold text-lg">
                  Crowd Prediction
                </h2>

                <p className="text-xs opacity-90">
                  AI Tourist Crowd Analyzer
                </p>

              </div>

            </div>

            <button
              onClick={() => setIsOpen(false)}
            >
              <X className="w-5 h-5" />
            </button>

          </div>

          {/* FORM */}

          <form
            onSubmit={predictCrowd}
            className="p-5 space-y-4"
          >

            {/* TEMPERATURE */}

            <div>

              <label className="text-sm font-semibold text-gray-700">
                Temperature (°C)
              </label>

              <input
                type="number"
                name="temperature"
                value={formData.temperature}
                onChange={handleChange}
                required
                className="
                  w-full
                  mt-1
                  p-3
                  border
                  rounded-xl
                  focus:outline-none
                  focus:ring-2
                  focus:ring-orange-400
                "
              />

            </div>

            {/* HUMIDITY */}

            <div>

              <label className="text-sm font-semibold text-gray-700">
                Humidity (%)
              </label>

              <input
                type="number"
                name="humidity"
                value={formData.humidity}
                onChange={handleChange}
                required
                className="
                  w-full
                  mt-1
                  p-3
                  border
                  rounded-xl
                  focus:outline-none
                  focus:ring-2
                  focus:ring-orange-400
                "
              />

            </div>

            {/* RAINFALL */}

            <div>

              <label className="text-sm font-semibold text-gray-700">
                Rainfall (mm)
              </label>

              <input
                type="number"
                name="rainfall"
                value={formData.rainfall}
                onChange={handleChange}
                required
                className="
                  w-full
                  mt-1
                  p-3
                  border
                  rounded-xl
                  focus:outline-none
                  focus:ring-2
                  focus:ring-orange-400
                "
              />

            </div>

            {/* HOUR */}

            <div>

              <label className="text-sm font-semibold text-gray-700">
                Hour
              </label>

              <input
                type="number"
                name="hour"
                value={formData.hour}
                onChange={handleChange}
                required
                className="
                  w-full
                  mt-1
                  p-3
                  border
                  rounded-xl
                  focus:outline-none
                  focus:ring-2
                  focus:ring-orange-400
                "
              />

            </div>

            {/* HOLIDAY */}

            <div>

              <label className="text-sm font-semibold text-gray-700">
                Holiday
              </label>

              <select
                name="holiday"
                value={formData.holiday}
                onChange={handleChange}
                className="
                  w-full
                  mt-1
                  p-3
                  border
                  rounded-xl
                  focus:outline-none
                  focus:ring-2
                  focus:ring-orange-400
                "
              >

                <option value="0">No</option>

                <option value="1">Yes</option>

              </select>

            </div>

            {/* WEEKEND */}

            <div>

              <label className="text-sm font-semibold text-gray-700">
                Weekend
              </label>

              <select
                name="weekend"
                value={formData.weekend}
                onChange={handleChange}
                className="
                  w-full
                  mt-1
                  p-3
                  border
                  rounded-xl
                  focus:outline-none
                  focus:ring-2
                  focus:ring-orange-400
                "
              >

                <option value="0">No</option>

                <option value="1">Yes</option>

              </select>

            </div>

            {/* BUTTON */}

            <button
              type="submit"
              disabled={loading}
              className="
                w-full
                bg-orange-500
                hover:bg-orange-600
                text-white
                py-3
                rounded-2xl
                font-semibold
                transition-all
              "
            >

              {loading ? "Predicting..." : "Predict Crowd"}

            </button>

          </form>

          {/* RESULT */}

          {prediction && (

            <div className="px-5 pb-5">

              <div
                className="
                  bg-orange-50
                  border
                  border-orange-200
                  rounded-2xl
                  p-4
                  text-center
                "
              >

                <h3 className="text-lg font-bold text-orange-600">

                  {prediction.crowd_level}

                </h3>

                <p className="text-gray-700 mt-2">

                  Crowd Percentage:
                  <span className="font-bold">
                    {" "}
                    {prediction.confidence}%
                  </span>

                </p>

              </div>

            </div>

          )}

        </div>

      )}

    </>
  );
};

export default CrowdPredictionWidget;