import React, { useState } from 'react';
import api from '../services/api';
import { Sparkles, Map as MapIcon, Users, Calendar, Wallet } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const AIItinerary = () => {
  const [formData, setFormData] = useState({ destination: 'Mahabaleshwar', days: 3, budget: 'Moderate', people: 2 });
  const [itinerary, setItinerary] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.post('/ai/itinerary', formData);
      setItinerary(res.data.data);
    } catch (err) {
      console.error(err);
      setItinerary('Failed to generate itinerary. Please make sure the backend AI service is running and configured.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <Sparkles className="w-12 h-12 text-emerald-600 mx-auto mb-4" />
        <h1 className="text-4xl font-extrabold text-gray-900">AI Itinerary Planner</h1>
        <p className="text-lg text-gray-600 mt-2">Let our AI build the perfect trip for you.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 bg-white p-8 rounded-xl shadow-sm border border-gray-200">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="flex items-center text-sm font-semibold text-gray-700 mb-2">
                <MapIcon className="w-4 h-4 mr-2" /> Destination
              </label>
              <input type="text" value={formData.destination} onChange={(e) => setFormData({...formData, destination: e.target.value})} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none" required />
            </div>
            <div>
              <label className="flex items-center text-sm font-semibold text-gray-700 mb-2">
                <Calendar className="w-4 h-4 mr-2" /> Days
              </label>
              <input type="number" min="1" max="14" value={formData.days} onChange={(e) => setFormData({...formData, days: parseInt(e.target.value)})} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none" required />
            </div>
            <div>
              <label className="flex items-center text-sm font-semibold text-gray-700 mb-2">
                <Wallet className="w-4 h-4 mr-2" /> Budget
              </label>
              <select value={formData.budget} onChange={(e) => setFormData({...formData, budget: e.target.value})} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                <option>Budget-friendly</option>
                <option>Moderate</option>
                <option>Luxury</option>
              </select>
            </div>
            <div>
              <label className="flex items-center text-sm font-semibold text-gray-700 mb-2">
                <Users className="w-4 h-4 mr-2" /> People
              </label>
              <input type="number" min="1" max="20" value={formData.people} onChange={(e) => setFormData({...formData, people: parseInt(e.target.value)})} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none" required />
            </div>
            <button type="submit" disabled={loading} className="w-full bg-emerald-600 text-white font-bold py-3 rounded-lg hover:bg-emerald-700 transition disabled:opacity-50">
              {loading ? 'Generating Plan...' : 'Generate Plan'}
            </button>
          </form>
        </div>

        <div className="lg:col-span-2 bg-white p-8 rounded-xl shadow-sm border border-gray-200 min-h-[500px]">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-full text-emerald-600 animate-pulse">
              <Sparkles className="w-12 h-12 mb-4" />
              <p className="text-xl font-semibold">Gemini is planning your trip...</p>
            </div>
          ) : itinerary ? (
            <div className="prose prose-emerald max-w-none">
              <ReactMarkdown>{itinerary}</ReactMarkdown>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-gray-400">
              <MapIcon className="w-16 h-16 mb-4 opacity-50" />
              <p className="text-lg">Your generated itinerary will appear here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIItinerary;
